English main.tex is self-contained and uses pdfLaTeX.
The Chinese PDF is a translation companion, not a second study.
toy_authority.py and authority-results.json reproduce the finite-state illustration.
No font files, credentials, or independent arXiv submission are included.
Manuscript rights: COPYRIGHT.md. Code: LICENSE-CODE (MIT), not the manuscript.
The arXiv distribution license remains unselected.
